import { Component } from '@angular/core';

@Component({
  selector: 'app-page-refresh',
  standalone: true,
  imports: [],
  templateUrl: './page-refresh.component.html',
  styleUrl: './page-refresh.component.scss'
})
export class PageRefreshComponent {

}
